import sys


print(sys.version, sys.platform)


# данные по системе:
#
# 3.7.4 (tags/v3.7.4:e09359112e, Jul  8 2019, 19:29:22) [MSC v.1916 32 bit (Intel)] win32
